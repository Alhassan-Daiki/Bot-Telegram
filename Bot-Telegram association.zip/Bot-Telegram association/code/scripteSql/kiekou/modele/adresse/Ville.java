package kiekou.modele.adresse ;

public class Ville {
    private String mNom;

    public String getMNom() {
        return this.mNom;
    }

    public void setMNom(final String value) {
        this.mNom = value;
    }

}
