package kiekou.modele.adresse ;

public class Lieu_de_reference {
    private String mNom;

    public String getMNom() {
        return this.mNom;
    }

    public void setMNom(final String value) {
        this.mNom = value;
    }

}
