package kiekou.modele.service ;

public class HorraireParJour {
    private String mJour;

    public String getJour() {
        return this.mJour;
    }

    public void setJour(final String value) {
        this.mJour = value;
    }

}
