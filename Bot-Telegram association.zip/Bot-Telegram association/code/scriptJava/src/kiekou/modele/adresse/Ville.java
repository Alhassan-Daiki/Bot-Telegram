package kiekou.modele.adresse ;

import kiekou.modele.adresse.Region;
import kiekou.modele.adresse.Quartier;

public class Ville {
    private String mNom;

    private Region region;



    public String getMNom() {
        return this.mNom;
    }

    public void setMNom(final String value) {
        this.mNom = value;
    }

}
