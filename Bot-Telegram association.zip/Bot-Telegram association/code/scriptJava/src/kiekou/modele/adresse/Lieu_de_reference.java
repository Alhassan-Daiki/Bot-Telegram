package kiekou.modele.adresse ;

import kiekou.modele.adresse.Quartier;


public class Lieu_de_reference {
    private String mNom;

    private Quartier quartier;



    public String getMNom() {
        return this.mNom;
    }

    public void setMNom(final String value) {
        this.mNom = value;
    }

}
