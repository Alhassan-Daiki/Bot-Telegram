package kiekou.modele.adresse ;

import kiekou.modele.adresse.Ville;

import kiekou.modele.adresse.Lieu_de_reference;


public class Quartier {
    private String mNom;

    private Ville ville;


    public String getMNom() {
        return this.mNom;
    }

    public void setMNom(final String value) {
        this.mNom = value;
    }

}
