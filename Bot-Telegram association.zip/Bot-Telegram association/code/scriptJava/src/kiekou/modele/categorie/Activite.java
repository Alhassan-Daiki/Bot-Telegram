package kiekou.modele.categorie ;

import kiekou.modele.categorie.Categorie;
import kiekou.modele.service.Service;

public class Activite {
    private String mNom;

    private Categorie categorie;

    /*public Activite(String _mNom, Categorie _categorie){
        mNom = _mNom;
        categorie = _categorie;
    }*/

    public String getMNom() {
        return this.mNom;
    }

    public void setMNom(final String value) {
        this.mNom = value;
    }

}
