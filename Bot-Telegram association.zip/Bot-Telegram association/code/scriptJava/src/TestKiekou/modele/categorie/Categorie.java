package TestKiekou.modele.categorie ;

public class Categorie {
    private String mNom;

    public void setMNom(final String value) {
        this.mNom = value;
    }

    public String getMNom() {
        return this.mNom;
    }

}
