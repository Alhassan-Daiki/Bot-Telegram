package TestKiekou.modele.categorie ;

public class Activite {
    private String mNom;

    public String getMNom() {
        return this.mNom;
    }

    public void setMNom(final String value) {
        this.mNom = value;
    }

}
