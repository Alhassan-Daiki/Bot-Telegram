package TestKiekou.modele.service ;

public class TestHorraireParJour {
    private String mJour;

    public String getJour() {
        return this.mJour;
    }

    public void setJour(final String value) {
        this.mJour = value;
    }

}
