package TestKiekou.modele.service ;


import kiekou.modele.service.Personne;

public class TestPersonne {
    private String mNom;

    private String mPrenom;

    private String mContact;

    @Test
    public void TestGetmNom() {
        // Arrange
        String mNom = "Daiki";

        //Act 
        String Resultat = Personne.getmNom(mNom);

        //Assert
        assertEquals("Daiki", Resultat);
    }

    @Test
    public String TestGetmPrenom() {
        String mPrenom = "Alhasan";

        String Resultat = Personne.getmPrenom(mPrenom);

        assertEquals("Alhasan", Resultat);
    }

    @Test
    public String TestGetmContact() {
        String mContact = "91-81-79-07";

        String Resultat = Personne.getmContact(mContact);

        assertEquals("91-81-79-07", Resultat);
    }


}
