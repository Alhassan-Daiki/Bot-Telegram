package TestKiekou.modele.service;

public @interface Test {

}
