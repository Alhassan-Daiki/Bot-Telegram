package TestKiekou.modele.service ;

import kiekou.modele.service.Service;

public class TestService {
    private String mDesignation;

    private String mDescription;

    private int mNote;


    public TestService() {
    }
    @Test
    public void TestGetMDesignation() {
        String mDesignation = "Coordonerie";

        String Resultat = Service.getMDescription(mDesignation);

        assertEquals("Cooedonerie", Resultat);
    }

    @Test
    public void TestGetMDescription() {
        String mDescription = "";

        String Resultat = Service.getMDescription(mDescription);

        assertEquals("", Resultat);
    }


    @Test
    public void TestGetMNote() {
        int mNote = 15;

        int Resultat = Service.getMNote(mNote);

        assertEquals(15, Resultat);
    }


    


}
